# src/jet/engine_unsloth.py
import torch
from transformers import set_seed
from trl import SFTTrainer, SFTConfig

# Placeholder to avoid importing Unsloth (which triggers GPU checks) at module import.
class FastLanguageModel:
    _placeholder = True
    @staticmethod
    def from_pretrained(*args, **kwargs):
        raise RuntimeError("UNSLOTH_PLACEHOLDER")
    @staticmethod
    def get_peft_model(model, **kwargs):
        raise RuntimeError("UNSLOTH_PLACEHOLDER")

def _normalize_precision(opts):
    cuda = torch.cuda.is_available()
    xpu = hasattr(torch, "xpu") and torch.xpu.is_available()
    # Disable mixed precision and 4-bit on CPU
    if not (cuda or xpu):
        return torch.float32, False, False, False  # dtype, use_bf16, use_fp16, use_4bit
    # Prefer bf16 on supported GPUs, else fp16
    if cuda and hasattr(torch.cuda, "is_bf16_supported") and torch.cuda.is_bf16_supported():
        return torch.bfloat16, True, False, opts.use_4bit
    return torch.float16, False, True, opts.use_4bit

def _import_unsloth():
    from unsloth import FastLanguageModel as _RealFastLanguageModel
    return _RealFastLanguageModel

def _ensure_unsloth_loaded():
    global FastLanguageModel
    if getattr(FastLanguageModel, "_placeholder", False):
        FastLanguageModel = _import_unsloth()

def _build_sft_config(opts, use_bf16, use_fp16, include_field=True):
    base = dict(
        output_dir=opts.output_dir,
        per_device_train_batch_size=opts.per_device_batch,
        gradient_accumulation_steps=opts.grad_accum,
        learning_rate=opts.lr,
        num_train_epochs=opts.epochs,
        bf16=use_bf16,
        fp16=use_fp16,
        logging_steps=50,
        save_strategy="epoch",
        report_to=[],
        packing=False,
    )
    if include_field:
        base["dataset_text_field"] = opts.text_field or "text"
    try:
        return SFTConfig(**base), True
    except TypeError:
        if "dataset_text_field" in base:
            base.pop("dataset_text_field", None)
            return SFTConfig(**base), False
        raise

def _make_trainer(model, tok, train_ds, eval_ds, sft_cfg, dataset_field_name):
    kwargs = dict(model=model, train_dataset=train_ds, eval_dataset=eval_ds, args=sft_cfg)
    variants = ("tokenizer_only", "processing_only", "tokenizer_plus_field", "processing_plus_field")
    tried = []
    for v in variants:
        try:
            if v == "tokenizer_only":
                tried.append(v)
                return SFTTrainer(tokenizer=tok, **kwargs)
            if v == "processing_only":
                tried.append(v)
                return SFTTrainer(processing_class=tok, **kwargs)
            if v == "tokenizer_plus_field":
                tried.append(v)
                return SFTTrainer(tokenizer=tok, dataset_text_field=dataset_field_name, **kwargs)
            if v == "processing_plus_field":
                tried.append(v)
                return SFTTrainer(processing_class=tok, dataset_text_field=dataset_field_name, **kwargs)
        except TypeError:
            continue
    raise TypeError(f"SFTTrainer construction failed for variants: {tried}")

def train(opts, train_ds, eval_ds=None):
    set_seed(opts.seed)
    dtype, use_bf16, use_fp16, use_4bit = _normalize_precision(opts)

    # Try current binding first (DI/tests), otherwise lazily import Unsloth
    try:
        model, tok = FastLanguageModel.from_pretrained(
            model_name=opts.model,
            max_seq_length=opts.max_seq,
            load_in_4bit=use_4bit,
            dtype=dtype,
            device_map="auto",
        )
    except RuntimeError as e:
        if "UNSLOTH_PLACEHOLDER" not in str(e):
            raise
        try:
            _ensure_unsloth_loaded()
            model, tok = FastLanguageModel.from_pretrained(
                model_name=opts.model,
                max_seq_length=opts.max_seq,
                load_in_4bit=use_4bit,
                dtype=dtype,
                device_map="auto",
            )
        except NotImplementedError as ne:
            # Clear guidance for CPU-only users: HF engine should be used
            raise RuntimeError("Unsloth requires NVIDIA CUDA or Intel XPU; use engine='hf' on CPU.") from ne
        except Exception as ie:
            raise RuntimeError(f"Unsloth load failed: {ie}")

    # Tokenizer safety
    if getattr(tok, "pad_token", None) is None:
        tok.pad_token = getattr(tok, "eos_token", None) or "<|pad|>"
    tok.padding_side = "right"

    # LoRA with Unsloth helper
    try:
        model = FastLanguageModel.get_peft_model(
            model,
            r=16,
            lora_alpha=32,
            lora_dropout=0.05,
            target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
            bias="none",
            use_gradient_checkpointing="unsloth",
        )
    except RuntimeError as e:
        if "UNSLOTH_PLACEHOLDER" in str(e):
            _ensure_unsloth_loaded()
            model = FastLanguageModel.get_peft_model(
                model,
                r=16,
                lora_alpha=32,
                lora_dropout=0.05,
                target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
                bias="none",
                use_gradient_checkpointing="unsloth",
            )
        else:
            raise

    # Prefer flash attention when available
    if hasattr(model.config, "attn_implementation"):
        model.config.attn_implementation = "flash_attention_2"

    # TRL config and trainer (version-tolerant)
    sft_cfg, cfg_has_field = _build_sft_config(opts, use_bf16, use_fp16, include_field=True)
    dataset_field_name = opts.text_field or "text"
    trainer = _make_trainer(
        model, tok, train_ds, eval_ds, sft_cfg,
        dataset_field_name if not cfg_has_field else None
    )

    trainer.train()
    trainer.save_model(opts.output_dir)
    tok.save_pretrained(opts.output_dir)

    return type("Job", (), {"model_dir": opts.output_dir})
