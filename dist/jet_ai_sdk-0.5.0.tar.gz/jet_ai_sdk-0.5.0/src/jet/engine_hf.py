# src/jet/engine_hf.py
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, set_seed
from trl import SFTTrainer, SFTConfig

def _normalize_precision(opts):
    cuda = torch.cuda.is_available()
    xpu = hasattr(torch, "xpu") and torch.xpu.is_available()
    if not (cuda or xpu):
        return torch.float32, False, False  # dtype, use_bf16, use_fp16
    if cuda and hasattr(torch.cuda, "is_bf16_supported") and torch.cuda.is_bf16_supported():
        return torch.bfloat16, True, False
    return torch.float16, False, True

def _build_sft_config(opts, use_bf16, use_fp16, include_field=True):
    base = dict(
        output_dir=opts.output_dir,
        per_device_train_batch_size=opts.per_device_batch,
        gradient_accumulation_steps=opts.grad_accum,
        learning_rate=opts.lr,
        num_train_epochs=opts.epochs,
        bf16=use_bf16,
        fp16=use_fp16,
        logging_steps=50,
        save_strategy="epoch",
        report_to=[],
        packing=False,
    )
    if include_field:
        base["dataset_text_field"] = opts.text_field or "text"
    try:
        return SFTConfig(**base), True
    except TypeError:
        if "dataset_text_field" in base:
            base.pop("dataset_text_field", None)
            return SFTConfig(**base), False
        raise

def _make_trainer(model, tok, train_ds, eval_ds, sft_cfg, dataset_field_name):
    kwargs = dict(model=model, train_dataset=train_ds, eval_dataset=eval_ds, args=sft_cfg)
    variants = ("tokenizer_only", "processing_only", "tokenizer_plus_field", "processing_plus_field")
    tried = []
    for v in variants:
        try:
            if v == "tokenizer_only":
                tried.append(v)
                return SFTTrainer(tokenizer=tok, **kwargs)
            if v == "processing_only":
                tried.append(v)
                return SFTTrainer(processing_class=tok, **kwargs)
            if v == "tokenizer_plus_field":
                tried.append(v)
                return SFTTrainer(tokenizer=tok, dataset_text_field=dataset_field_name, **kwargs)
            if v == "processing_plus_field":
                tried.append(v)
                return SFTTrainer(processing_class=tok, dataset_text_field=dataset_field_name, **kwargs)
        except TypeError:
            continue
    raise TypeError(f"SFTTrainer construction failed for variants: {tried}")

def train(opts, train_ds, eval_ds=None):
    set_seed(opts.seed)
    dtype, use_bf16, use_fp16 = _normalize_precision(opts)

    tok = AutoTokenizer.from_pretrained(opts.model, use_fast=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "right"

    # Enforce dtype for consistent CPU/GPU behavior
    model = AutoModelForCausalLM.from_pretrained(opts.model, torch_dtype=dtype)

    sft_cfg, cfg_has_field = _build_sft_config(opts, use_bf16, use_fp16, include_field=True)
    dataset_field_name = opts.text_field or "text"
    trainer = _make_trainer(
        model, tok, train_ds, eval_ds, sft_cfg,
        dataset_field_name if not cfg_has_field else None
    )

    trainer.train()
    trainer.save_model(opts.output_dir)
    tok.save_pretrained(opts.output_dir)
    return type("Job", (), {"model_dir": opts.output_dir})
