# src/jet/__init__.py
__version__ = "0.4.4"


