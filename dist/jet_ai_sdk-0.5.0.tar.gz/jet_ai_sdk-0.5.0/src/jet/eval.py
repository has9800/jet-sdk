# src/jet/eval.py
import os
from typing import List, Dict, Any, Optional
from transformers import AutoTokenizer, AutoModelForCausalLM  # Evaluator loads via Auto* [web:1278]

def _resolve_model_source(path_or_id: str, allow_fallback: bool = True, fallback_model_id: str = "sshleifer/tiny-gpt2") -> str:
    """
    Resolve a source that may be a local directory or a HF repo ID.
    - If it's a directory with config.json, return the path.
    - If it's a directory without config.json, fall back (if allowed) or raise with guidance.
    - Otherwise, treat as a model ID and return it.
    """
    if os.path.isdir(path_or_id):
        cfg = os.path.join(path_or_id, "config.json")
        if os.path.exists(cfg):
            return path_or_id  # valid local model dir [web:1278]
        if allow_fallback:
            return fallback_model_id  # fallback to known tiny model for smokes [web:1279]
        raise ValueError(
            f"Invalid model directory '{path_or_id}': missing config.json with a 'model_type'. "
            f"Pass a proper saved model directory (after training) or a known HF model ID."
        )  # clear guidance on model_type/config [web:1278][web:1283]
    return path_or_id  # assume HF model ID [web:1278]

class Evaluator:
    def __init__(
        self,
        model_dir_or_id: str,
        bf16: bool = False,  # unused here but kept for interface stability
        allow_fallback: bool = True,
        fallback_model_id: str = "sshleifer/tiny-gpt2",
    ):
        src = _resolve_model_source(model_dir_or_id, allow_fallback=allow_fallback, fallback_model_id=fallback_model_id)  # resolve path/id [web:1278]
        # If src is a fallback, we’ll download minimal weights; for a valid local dir this loads from disk. [web:1279]
        self.tok = AutoTokenizer.from_pretrained(src, use_fast=True)  # load tokenizer [web:1278]
        self.model = AutoModelForCausalLM.from_pretrained(src)  # load model [web:1278]
        try:
            self.model.eval()  # eval mode if available [web:1278]
        except Exception:
            pass

    def evaluate(self, prompts: List[str], references: Optional[List[str]] = None) -> Dict[str, Any]:
        preds: List[str] = []
        for p in prompts:
            enc = self.tok(p, return_tensors="pt")  # prepare input [web:1278]
            out = self.model.generate(**enc, max_new_tokens=16)  # small generation for smoke [web:1278]
            # Handle list/tensor-like outputs uniformly
            first = out[0] if isinstance(out, (list, tuple)) else out[0]
            txt = self.tok.decode(first, skip_special_tokens=True)  # decode tokens [web:1278]
            preds.append(txt)
        return {"count": len(preds), "preds": preds, "refs": references or []}  # minimal report [web:1278]
